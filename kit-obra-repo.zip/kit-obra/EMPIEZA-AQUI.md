# Empieza aquí

Esto es un kit de arranque para que no empieces con Claude desde cero. Trae
formatos de obra con criterio (actas, bitácoras, informes, control de cambios,
gestión documental), un revisor que verifica documentos antes de que los mandes,
y una entrevista inicial que adapta todo a tu proyecto y a tu forma de trabajar.

Léelo completo: son cinco minutos y te ahorra las dos semanas de andar
descubriendo qué se puede pedir y qué no.

---

## 1. Instálalo

Hay dos vías. **Con una basta.**

### Vía A — el archivo `.plugin` (la más rápida)

Si te llegó el archivo `kit-obra.plugin`:

1. Abre Claude en el escritorio.
2. Arrastra el archivo al chat.
3. Aparece una vista previa con un botón para instalarlo. Acéptalo.

Listo. No hay que descargar nada más.

### Vía B — desde el repositorio (la que se puede actualizar)

Si te pasaron el enlace del repositorio, en Claude Code:

```
/plugin marketplace add USUARIO/REPO
/plugin install kit-obra@kit-arranque
```

Reemplaza `USUARIO/REPO` por el enlace que te dieron. Cuando salga una versión
nueva del kit, la traes con:

```
/plugin marketplace update
```

En la app de escritorio la instalación desde repositorio se hace desde el
panel de plugins de la aplicación, agregando ese mismo repositorio.

---

## 2. Conecta tu carpeta de trabajo

Este es el paso que más rinde y el que casi todo el mundo se salta.

En la app de escritorio, busca **"Agregar carpeta"** y conecta la carpeta donde
tienes los archivos del proyecto. A partir de ahí Claude puede leer tus actas,
tus bitácoras y tus planos, y escribir los documentos nuevos **directamente
ahí**, sin que tengas que estar subiendo y bajando archivos.

Si trabajas en Google Drive, conecta también el conector de Google Drive: para
archivos que ya están en Drive es más rápido y consume mucho menos que abrirlos
por el navegador.

---

## 3. Antes de la entrevista, reúne esto

La entrevista inicial sirve para que el kit deje de ser genérico y se parezca a
lo que tú ya haces. Para eso necesita ver tu trabajo. Ten a la mano:

- [ ] Un **acta** reciente tuya (aunque tenga datos que después toque tapar)
- [ ] Una **bitácora** o registro diario reciente
- [ ] La **plantilla oficial** de tu empresa, si existe
- [ ] Un **informe de avance** anterior
- [ ] La **programación de obra** (Project, Excel o PDF)
- [ ] El **presupuesto** o el listado de actividades con cantidades

Si no tienes todos, arranca igual con lo que haya. Pero cada archivo que
compartas es una plantilla menos que después toca corregir a mano.

---

## 4. Arranca

Escríbele a Claude, tal cual:

```
empecemos
```

Eso dispara la entrevista. Dura entre 15 y 30 minutos, va por bloques, y no
termina con un tutorial: **termina con un documento real tuyo, hecho con tus
datos**. Elige tú cuál: el que hoy más tiempo te quita.

La entrevista te va a preguntar por tu rol, tu proyecto, qué documentos
produces y con qué ritmo, dónde viven tus archivos, y cómo prefieres que Claude
trabaje contigo. Responde con detalle: lo que contestes ahí se guarda y no hay
que repetirlo en cada sesión.

Al final se crea un archivo `PERFIL.md` en tu carpeta. **Ábrelo y corrígelo.**
Ese archivo manda sobre las plantillas del kit: si algo quedó mal entendido, se
arregla ahí y Claude lo respeta de ahí en adelante.

---

## 5. Cómo se usa el día a día

No hay que aprender comandos. Se pide en español normal y la skill que
corresponde se activa sola:

| Lo que escribes | Lo que pasa |
|---|---|
| "haz el acta del comité de hoy" (y le pasas tus notas o el audio) | Acta completa con compromisos, responsables y fechas |
| "bitácora de hoy" y le dictas el día | Registro diario con la estructura completa |
| "cómo vamos contra la programación" | Informe de avance con ejecutado vs. programado y causas |
| "levanta una solicitud de cambio por lo de la cimentación" | Solicitud con alternativas, impacto en costo y plazo |
| "ordena esta carpeta" | Inventario, nomenclatura propuesta y consecutivos |
| "revisa esto antes de que lo mande" | El revisor te dice qué le falta y dónde estás expuesto |
| "hazme un formulario para que el maestro reporte el día" | Herramienta de captura pensada para campo |

---

## 6. Tres cosas que conviene saber de entrada

**Claude no adivina.** Si un dato no lo diste, va a quedar marcado como
`[POR CONFIRMAR]` en el documento. Eso es a propósito: es preferible un campo
vacío visible a un dato inventado que se te cuele en un acta firmada.

**Lo textual y lo interpretado van separados.** En actas e informes, primero va
lo que se dijo y lo que pasó; las lecturas y sugerencias de Claude van en una
sección aparte al final, marcada como que no hace parte del documento. Si algún
día quieres que las mezcle, se lo pides — pero por defecto van separadas por
una razón: un acta con interpretaciones adentro se puede objetar.

**Las referencias normativas son un punto de partida, no una verdad.** El kit
cita normativa colombiana (Título I de la NSR-10 para registros de supervisión
técnica, entre otras). Antes de copiar una cita en un documento que vas a
firmar, verifícala contra tu contrato y la norma vigente. Manda el contrato.

---

## 7. Si algo no te sirve

El kit está hecho para que lo cambies. Cuando un documento salga distinto de
como lo necesitas, no lo corrijas a mano cada vez: díselo a Claude y pídele que
actualice el perfil. Por ejemplo:

> "En mis actas el consecutivo va con el año adelante, así: ACT-2026-012.
> Actualiza el perfil."

Y si un formato completo te parece mal planteado, dilo. Discutirlo mejora el
kit; aceptarlo tal cual solo hace que lo abandones en un mes.
