# Estructura de carpetas sugerida

Proponerla, no imponerla. Si el usuario ya tiene una estructura que funciona,
respetarla y solo documentarla en PERFIL.md.

La lógica: **una carpeta por proyecto, y dentro, una carpeta por tipo de
documento con numeración consecutiva**. Nada de carpetas por mes: los
consecutivos ya ordenan en el tiempo y las carpetas por mes rompen la
trazabilidad de una serie.

```
PROYECTOS/
├── PERFIL.md
├── 2026-CASA-LOPEZ/
│   ├── 00-CONTRATO/           contrato, otrosíes, pólizas, licencias
│   ├── 01-BITACORA/           BIT-001.md, BIT-002.md ...
│   ├── 02-ACTAS/              ACT-001-comite.md ...
│   ├── 03-INFORMES/           INF-001-semanal.md ...
│   ├── 04-CAMBIOS/            SC-001.md, NC-001.md, RFI-001.md
│   ├── 05-CORRESPONDENCIA/    radicados entrada y salida
│   ├── 06-PLANOS/             por disciplina y versión
│   ├── 07-ENSAYOS/            resultados de laboratorio
│   ├── 08-REGISTRO-FOTO/      AAAA-MM-DD_ubicacion_descripcion.jpg
│   └── 09-PAGOS/              cortes de obra y actas parciales
└── _PLANTILLAS/               formatos propios de la empresa
```

Notas de criterio:

- **`08-REGISTRO-FOTO` no es opcional.** El registro fotográfico es parte de
  los registros exigidos a la supervisión técnica y es la primera prueba que se
  pide cuando hay una controversia.
- Los documentos que se firman circulan en PDF, pero **el original de trabajo
  se guarda en formato editable**. Guardar solo el PDF firmado deja al usuario
  sin poder reconstruir un anexo.
- La carpeta `00-CONTRATO` se lee primero en cualquier tarea nueva: define qué
  documento es exigible, con qué frecuencia y ante quién.
