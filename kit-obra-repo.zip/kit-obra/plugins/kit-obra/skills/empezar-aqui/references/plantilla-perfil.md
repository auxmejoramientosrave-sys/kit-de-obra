# Plantilla de PERFIL.md

Escribir este archivo en la raíz de la carpeta de trabajo del usuario.
Rellenar solo con lo que el usuario dijo. Lo que no se preguntó o no se
respondió va como `[POR DEFINIR]`, nunca inventado.

```markdown
# Perfil de trabajo

_Última actualización: AAAA-MM-DD. Editable: corrige lo que esté mal y
Claude lo respeta a partir de la siguiente sesión._

## Quién soy
- Nombre:
- Cargo:
- Empresa / independiente:
- Ciudad y país:
- Rol frente a la obra: (constructor / interventoría / supervisión / diseño / propietario)
- Proyectos simultáneos:

## Proyecto activo
- Nombre:
- Tipo de obra:
- Contrato: (número, modalidad, público o privado)
- Fecha de inicio / plazo:
- Estado actual:

### Actores
| Rol | Nombre | Empresa | Contacto |
|---|---|---|---|
| Residente | | | |
| Director de obra | | | |
| Interventoría | | | |
| Supervisión técnica | | | |
| Cliente / propietario | | | |

## Documentos que produzco
| Documento | Frecuencia | Para quién | Formato de salida | Quién aprueba |
|---|---|---|---|---|
| Bitácora | | | | |
| Acta de comité | | | | |
| Informe de avance | | | | |
| Corte de obra | | | | |

**El que más tiempo me quita:**

## Convenciones detectadas en mis formatos
_Extraídas de los archivos de referencia que compartí. Corregir si están mal._
- Numeración de actas:
- Numeración de bitácora:
- Nomenclatura de archivos:
- Encabezado obligatorio:
- Firmas requeridas:
- Tono de redacción:

## Herramientas
- Archivos viven en:
- Comunicación con el cliente por:
- Conectores activos:

## Cómo quiero que Claude trabaje
- Cuestionar vs. ejecutar:
- Separar lo textual de las recomendaciones: sí / no
- Nivel de formalidad:
- Idioma y formato de fecha:

## Pendientes de definir
- [ ]
```
