---
name: empezar-aqui
description: >
  Entrevista de arranque del Kit de Obra. Esta skill debe usarse la primera vez
  que el usuario abre el kit, o cuando diga "empecemos", "configúrame esto",
  "no sé por dónde empezar", "adáptame el kit a mi obra", "vuelve a configurar
  el kit" o "cambié de proyecto". Levanta el perfil del usuario y de su
  proyecto, pide archivos de referencia, escribe PERFIL.md y guarda lo durable
  en la memoria de Claude.
metadata:
  version: "0.1.0"
---

# Empezar aquí

Objetivo: en una sola conversación, pasar de "Claude no sabe nada de mí" a
"Claude conoce mi obra, mis formatos y mi rutina, y ya produjo algo que sirve".

No entregar el kit en abstracto. Terminar la sesión con un documento real hecho
con datos reales del usuario.

## Reglas de la entrevista

- Preguntar **por bloques**, no todo de una vez. Máximo 3–4 preguntas por turno.
  Esperar respuesta antes de seguir.
- Usar la herramienta de preguntas de opción múltiple cuando existan opciones
  claras; texto libre cuando la respuesta sea un nombre, una cifra o un proceso.
- Si el usuario responde algo vago ("hago informes"), repreguntar por lo
  concreto: cada cuánto, para quién, en qué formato, quién lo aprueba.
- No inventar. Si un dato no se obtuvo, dejarlo marcado como `[POR DEFINIR]` en
  PERFIL.md y decírselo al usuario al final.
- Es una entrevista, no un formulario: comentar lo que se va entendiendo y
  señalar cuando algo que el usuario describe se ve frágil o costoso.

## Bloque 1 — Quién es y qué hace

1. Nombre, cargo y para quién trabaja (empresa propia, constructora,
   interventoría, entidad pública, independiente).
2. País y ciudad. **Este dato manda**: define normativa, nomenclatura de
   documentos y formatos de fecha y moneda. No asumirlo.
3. ¿De qué lado de la mesa está? Constructor, interventoría, supervisión
   técnica, diseño, propietario, o varios a la vez.
4. ¿Cuántos proyectos lleva al tiempo?

## Bloque 2 — El proyecto activo

1. Nombre del proyecto, tipo de obra (vivienda, institucional, vial, redes,
   remodelación) y magnitud aproximada.
2. Modalidad de contrato (precio global, precios unitarios, administración
   delegada) y si es público o privado. Esto cambia qué documento es exigible.
3. Fechas: inicio, plazo, y si ya hay suspensiones o prórrogas.
4. ¿Quiénes son los actores y cómo se llaman entre ellos? (residente,
   interventor, director, supervisor, cliente). Guardar los nombres reales:
   son los que van a aparecer en las actas.

## Bloque 3 — Qué documentos produce y con qué ritmo

Preguntar explícitamente por cada uno y anotar frecuencia, destinatario y
formato de salida (Word, PDF, Excel, correo, plataforma):

- Bitácora / libro de obra
- Actas de comité de obra o de reunión
- Informes de avance (semanal, quincenal, mensual)
- Cortes de obra / actas parciales
- Solicitudes de cambio, no conformidades, RFI
- Correspondencia formal radicada

Preguntar además: **¿cuál de estos le quita más tiempo hoy?** Esa es la skill
que se va a probar primero.

## Bloque 4 — Archivos de referencia (paso crítico)

Pedir explícitamente que comparta ejemplos de lo que ya hace. Sin esto, los
documentos salen genéricos.

Pedir, en orden de utilidad:

1. Un acta y una bitácora reales recientes (aunque tengan datos que luego
   toque anonimizar).
2. El formato o plantilla oficial de su empresa, si existe.
3. Un informe de avance anterior.
4. La programación de obra (Project, Excel o PDF).
5. El presupuesto o el listado de actividades con cantidades.

Ofrecer tres vías, en este orden: conectar la carpeta de trabajo desde la app
de escritorio, conectar Google Drive, o adjuntar los archivos al chat.

Al recibirlos, **leerlos y extraer**: campos del encabezado, numeración,
secciones, tono de redacción, quién firma, y cualquier convención de
nomenclatura de archivos. Devolverle al usuario un resumen de lo detectado y
confirmarlo antes de darlo por bueno.

## Bloque 5 — Herramientas y entorno

1. ¿Dónde viven los archivos? (carpeta local, Google Drive, OneDrive,
   SharePoint, plataforma del cliente)
2. ¿Por dónde llega y sale la información? (correo, WhatsApp, plataforma)
3. ¿Usa Claude en escritorio, en Claude Code, o ambos?
4. ¿Qué quiere automatizar primero si pudiera?

Conectar lo que aplique. Google Drive antes que el navegador para archivos que
ya están en Drive: es más rápido y más barato.

## Bloque 6 — Cómo quiere que Claude trabaje

1. ¿Prefiere que Claude cuestione y proponga, o que ejecute sin debate?
2. En resúmenes y actas: ¿separa lo textual de las recomendaciones? (el kit lo
   hace por defecto; confirmar que le sirve)
3. Nivel de formalidad del lenguaje: técnico-legal, técnico-neutro, o directo.

## Cierre — Escribir el perfil

1. Crear `PERFIL.md` en la carpeta de trabajo del usuario, con la estructura de
   `references/plantilla-perfil.md`. Es un archivo que él puede abrir y
   corregir; decírselo.
2. Guardar en la memoria de Claude solo lo **durable y no sensible**: rol,
   ciudad, tipo de obra, proyecto activo, herramientas, preferencias de
   trabajo, convenciones de sus formatos. No guardar cifras de contrato,
   salarios, datos personales de terceros ni información de salud.
3. Proponer la estructura de carpetas de `references/estructura-carpetas.md` y
   crearla solo si el usuario acepta.
4. **Ejecutar una tarea real de una vez**: tomar el documento que él dijo que
   más tiempo le quita y producirlo con la skill correspondiente, usando datos
   reales. Nunca cerrar la entrevista sin este paso.
5. Listar lo que quedó en `[POR DEFINIR]` y qué skill queda lista para usar.
