---
name: bitacora-obra
description: >
  Redacta y mantiene la bitácora o libro de obra: registro diario de personal,
  actividades, materiales, ensayos, novedades e instrucciones. Esta skill debe
  usarse cuando el usuario diga "bitácora de hoy", "registra lo de hoy en obra",
  "libro de obra", "anota esto en la bitácora", "pasa mis notas de campo a
  bitácora" o dicte lo que ocurrió en el día.
metadata:
  version: "0.1.0"
---

# Bitácora de obra

La bitácora es el documento con más peso probatorio de una obra y el que peor
se lleva. Su valor está en la constancia diaria, no en la elegancia: una
bitácora con huecos vale menos que una escueta pero completa.

## Reglas del registro

1. **Un registro por día calendario**, con consecutivo. Si un día no hubo
   actividad, se registra igual con la razón (lluvia, festivo, suspensión,
   falta de frente). Los días en blanco son los que después no se pueden
   defender.
2. **No se borra ni se corrige lo anterior.** Un error se aclara con una
   anotación nueva que referencia el registro corregido: "Se aclara el registro
   BIT-045 en el sentido de que...". Si el usuario pide sobrescribir un
   registro anterior, advertirlo antes de hacerlo.
3. **Hechos, no juicios.** "Se recibió el concreto a las 10:20 con 45 min de
   transporte" sí. "El concreto llegó tarde por culpa del proveedor" no.
4. **Ubicación siempre.** Toda actividad se amarra a eje, nivel, apartamento,
   abscisa o tramo. "Fundida de placa" sin ubicación no sirve para nada después.
5. **Lo que se ordena, se escribe.** Las instrucciones impartidas por la
   interventoría o la supervisión técnica se registran el mismo día, con quién
   las dio y a quién.

## Antes de escribir

Leer `PERFIL.md` para el consecutivo, el proyecto y los actores. Preguntar el
número del último registro si no consta. Si el usuario dicta varios días
atrasados, hacer un registro por día, no uno acumulado.

## Estructura del registro diario

```markdown
# BITÁCORA DE OBRA — Registro N.º [###]

| | |
|---|---|
| **Proyecto / Contrato** | [ ] |
| **Fecha** | [AAAA-MM-DD] — [día de la semana] |
| **Clima** | [mañana / tarde] |
| **Jornada** | [HH:MM] a [HH:MM] |
| **Elaboró** | [Nombre, cargo] |

## 1. Personal en obra
| Oficio | Cantidad |
|---|---|
| | |
**Total:** [ ]

## 2. Equipos en obra
| Equipo | Cantidad | Estado / horas |
|---|---|---|

## 3. Actividades ejecutadas
| Actividad | Ubicación (eje / nivel / tramo) | Avance | Observación |
|---|---|---|---|

## 4. Materiales recibidos
| Material | Cantidad | Proveedor | Remisión N.º | Conformidad |
|---|---|---|---|---|

## 5. Ensayos y controles de calidad
| Ensayo | Elemento | Muestra N.º | Laboratorio | Resultado |
|---|---|---|---|---|

## 6. Novedades e imprevistos
[Hechos con hora. Suspensiones, accidentes, hallazgos, interferencias,
retrasos y su causa observada.]

## 7. Instrucciones impartidas / recibidas
| Hora | Quién | A quién | Instrucción | Consta en |
|---|---|---|---|---|

## 8. Visitas
| Nombre | Entidad | Motivo | Hora |
|---|---|---|---|

## 9. Registro fotográfico
| Archivo | Ubicación | Descripción |
|---|---|---|

## 10. Firmas
| Nombre | Cargo | Firma |
|---|---|---|
```

## Marco normativo (Colombia)

Cuando la obra esté sujeta a supervisión técnica bajo el **Título I de la
NSR-10**, el registro escrito de la supervisión debe incluir como mínimo, según
el numeral I.2.2.1: las especificaciones de construcción y sus adendas, el
programa de control de calidad exigido, el **registro fotográfico** de la
construcción, los resultados e interpretación de los ensayos de materiales, la
correspondencia sobre deficiencias y correctivos ordenados, los conceptos de
los diseñadores, y la constancia final del supervisor —suscrita además por el
constructor y el titular de la licencia—. Esos documentos se entregan a la
autoridad de control urbano, al propietario y al constructor, y se conservan
**al menos cinco años** desde la terminación.

Consecuencia práctica: la bitácora sola no es el registro completo. Verificar
en cada proyecto que los ensayos, el registro fotográfico y la correspondencia
estén archivados y referenciados desde la bitácora.

Si el usuario no está en Colombia, o el contrato exige un formato propio,
**mandan el contrato y la normativa local**: preguntarlo y ajustar antes de
citar cualquier norma en un documento que él vaya a firmar.

## Salida semanal

Cuando el usuario lo pida, consolidar los registros de la semana en un resumen
con: días trabajados vs. calendario, promedio de personal, actividades
cerradas, novedades que afectaron el plazo y ensayos pendientes de resultado.
Ese consolidado alimenta la skill `informe-avance`.
