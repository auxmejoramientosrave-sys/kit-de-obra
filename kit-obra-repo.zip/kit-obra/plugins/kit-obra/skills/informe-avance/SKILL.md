---
name: informe-avance
description: >
  Arma informes de avance de obra y cortes: avance ejecutado vs. programado,
  curva S, cantidades, causas de desviación, riesgos y proyección. Esta skill
  debe usarse cuando el usuario diga "informe semanal", "informe mensual de
  obra", "corte de obra", "cómo vamos contra la programación", "avance del
  proyecto" o "prepara el informe para el cliente".
metadata:
  version: "0.1.0"
---

# Informe de avance

Un informe de avance responde tres preguntas y nada más: **dónde estamos, por
qué estamos ahí, y qué va a pasar si no cambia nada**. Todo lo demás es anexo.

## Antes de armar

Reunir las fuentes en este orden. Si falta alguna, decirlo explícitamente en el
informe en vez de estimar:

1. Programación vigente (línea base y última actualización aprobada).
2. Cantidades ejecutadas del periodo (de la bitácora o del corte).
3. Presupuesto o listado de actividades con pesos porcentuales.
4. Bitácoras del periodo — de ahí salen las causas reales de la desviación.
5. Actas del periodo — de ahí salen los compromisos y las decisiones.

## Cómo se calcula el avance (y cómo no)

- **Avance físico ponderado**: cada actividad aporta según su peso en el
  presupuesto, no según su duración. Sumar porcentajes sin ponderar da una
  cifra falsa y optimista.
- **Programado a la fecha** se lee de la programación al día de corte, no del
  plazo total transcurrido.
- **Desviación = ejecutado − programado**, en puntos porcentuales. Reportar
  también la desviación en días si la ruta crítica está afectada.
- Si una actividad está parcialmente ejecutada, medirla por cantidad real
  (m², m³, ml), nunca "a ojo". Si se estimó a ojo, escribir que fue estimado.

Cuando el usuario pida gráficas, generar la curva S (programado acumulado vs.
ejecutado acumulado) y un barras de avance por capítulo. Entregar los datos en
tabla junto a la gráfica: el cliente pregunta por el número, no por el dibujo.

## Estructura

```markdown
# INFORME DE AVANCE N.º [###]
**Proyecto:** [ ] · **Periodo:** [AAAA-MM-DD] a [AAAA-MM-DD] · **Corte:** [ ]

## 1. Resumen ejecutivo
[Máximo 6 líneas. Avance ejecutado, programado, desviación, y la única cosa
que el lector debe hacer después de leer esto.]

| Indicador | Valor |
|---|---|
| Avance físico ejecutado | X,X % |
| Avance físico programado | X,X % |
| Desviación | ±X,X pp |
| Días transcurridos / plazo | X / X |
| Estado | En plazo / En riesgo / Atrasado |

## 2. Avance por capítulo
| Capítulo | Peso % | Prog. acum. % | Ejec. acum. % | Desv. pp |
|---|---|---|---|---|

## 3. Actividades ejecutadas en el periodo
| Actividad | Unidad | Cantidad periodo | Acumulado | % de la actividad |
|---|---|---|---|---|

## 4. Causas de desviación
| Causa | Actividades afectadas | Impacto (días / pp) | Imputable a | Soporte |
|---|---|---|---|---|
[Imputable a: contratante / contratista / fuerza mayor / tercero. Este campo es
el que después sostiene o hunde una reclamación de plazo — soportarlo siempre
con acta, bitácora o comunicación radicada.]

## 5. Recursos del periodo
Personal promedio, equipos, rendimientos observados frente a los previstos.

## 6. Calidad
Ensayos realizados, resultados no conformes y su tratamiento.

## 7. Riesgos y alertas
| Riesgo | Probabilidad | Impacto | Acción propuesta | Responsable | Fecha |
|---|---|---|---|---|---|

## 8. Proyección
[Si se mantiene el rendimiento actual, fecha probable de terminación. Decir el
supuesto en voz alta: "asumiendo el rendimiento de las últimas 3 semanas".]

## 9. Solicitudes y decisiones requeridas
[Lo que el informe necesita que alguien decida, con fecha límite.]

## 10. Anexos
Registro fotográfico, cortes, actas, ensayos.

---

## Observaciones de Claude — no hacen parte del informe
[Lecturas propias, supuestos que se usaron, cifras que conviene verificar antes
de enviar, y dónde el informe está expuesto a que lo objeten.]
```

## Reglas de honestidad del informe

- No maquillar el avance moviendo pesos entre capítulos. Si el usuario lo
  propone, decirlo: es la forma más común de que un informe pierda credibilidad
  y la más fácil de detectar comparando dos cortes.
- Toda cifra debe poder rastrearse a una fuente. Si se estimó, marcarlo.
- Si el proyecto está atrasado, el resumen ejecutivo lo dice en la primera
  línea. Un atraso escondido en la página 6 se lee como intento de ocultarlo.
