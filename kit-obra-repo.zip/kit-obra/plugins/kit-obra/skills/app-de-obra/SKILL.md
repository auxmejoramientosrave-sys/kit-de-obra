---
name: app-de-obra
description: >
  Diseña y construye herramientas internas para obra: formularios de captura en
  campo, tableros de avance, calculadoras de cantidades, trackers de NC y RFI,
  y conversores de datos de obra. Esta skill debe usarse cuando el usuario diga
  "hazme una app para", "una herramienta para llevar", "un formulario para el
  maestro", "un tablero de avance", "quiero automatizar este Excel" o describa
  una tarea repetitiva de obra que hoy hace a mano.
metadata:
  version: "0.1.0"
---

# Herramientas internas de obra

Esta skill no reemplaza las skills de ingeniería que ya trae Claude
(`architecture`, `code-review`, `debug`, `testing-strategy`, `system-design`).
Las usa. Lo que aporta es el criterio del dominio: qué vale la pena construir
en obra y qué se abandona a las dos semanas.

## Antes de construir: la pregunta filtro

Preguntar y no saltarse esto: **¿quién va a meter los datos, en qué momento del
día, y con qué manos?**

La respuesta decide todo:

- Si el que captura es el maestro o el contratista a las 6 a.m. con guantes y
  el celular al sol, la herramienta tiene que ser un formulario de menos de 10
  campos, con botones grandes, que funcione **sin internet** y que no exija
  crear cuenta. Cualquier cosa más compleja no se llena.
- Si el que captura es el residente en la oficina de obra al final del día, se
  puede pedir más detalle.
- Si nadie tiene tiempo de capturar, no se construye una app: se construye un
  proceso que lea lo que ya existe (fotos, WhatsApp, el Excel del maestro).

**Herramienta que exige doble digitación está muerta antes de nacer.** Si los
datos ya están en un Excel o en la bitácora, la herramienta los lee de ahí.

## Qué construir primero

Orden de retorno real, de mayor a menor:

1. **Consolidadores**: leen los archivos que ya existen (bitácoras, cortes,
   Excel del maestro) y producen el informe. Cero cambio de hábito, valor
   inmediato.
2. **Formularios de captura** con salida a un solo archivo consolidado
   (bitácora diaria, lista de chequeo de calidad, recibo de material).
3. **Tableros de consulta** de lo ya capturado (avance por capítulo, NC
   abiertas, RFI vencidas).
4. **Calculadoras** de cantidades y APU parametrizados.
5. Sincronización en tiempo real, usuarios, permisos: **último**, y solo si el
   equipo ya usa lo anterior a diario.

## Decisiones técnicas por defecto

Para una herramienta interna de obra, salvo que el usuario pida otra cosa:

- **Una sola página HTML autocontenida** antes que un stack con backend. Se
  abre en cualquier celular, no requiere despliegue ni cuentas, y sobrevive a
  que el usuario cambie de computador.
- **Persistencia**: empezar por exportar a archivo (CSV, JSON, o el documento
  final). El almacenamiento del navegador se borra y no se comparte entre
  equipos: no guardar ahí nada que no se pueda perder.
- **Base de datos solo cuando hay más de un capturador** y se necesita ver lo
  del otro. Ahí sí, publicar la herramienta como artefacto con almacenamiento
  compartido, o usar una hoja de cálculo en la nube como respaldo — una hoja
  que el usuario puede abrir y arreglar a mano vale más que una base que solo
  entiende Claude.
- **Offline primero** en todo lo que se llene en campo. La cobertura en obra no
  se puede asumir.
- **Fotos**: comprimir en el cliente antes de guardar. Un formulario que sube
  fotos de 8 MB por datos móviles no se usa dos veces.

## Proceso

1. Definir el usuario, el momento de captura y los campos mínimos. Recortar
   campos hasta que duela.
2. Construir una versión mínima **con datos reales del proyecto**, no de
   ejemplo. El usuario debe poder juzgarla con sus propios números.
3. Probarla en el celular antes de entregarla. Si el usuario está en escritorio,
   pedirle que la abra en su teléfono y la llene una vez.
4. Recoger la fricción de esa primera prueba y recortar otra vez.
5. Solo entonces agregar funciones.

## Señales para no construir

Decirlo cuando aplique, en vez de construir:

- La tarea se hace una vez al mes y toma 15 minutos: no compensa.
- Ya existe una herramienta que el equipo usa y funciona: mejorar el flujo
  alrededor, no reemplazarla.
- El problema real es que nadie captura los datos: eso no lo arregla una app.
- El cliente exige su propia plataforma: construir para exportar hacia ella,
  no un sistema paralelo que después toca digitar dos veces.
