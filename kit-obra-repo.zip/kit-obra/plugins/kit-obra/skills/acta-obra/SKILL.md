---
name: acta-obra
description: >
  Redacta actas de comité de obra y de reunión a partir de notas, audios,
  transcripciones o una conversación con el usuario. Esta skill debe usarse
  cuando el usuario diga "haz el acta", "acta del comité", "acta de la reunión
  de hoy", "pasa esto a acta", "resume el comité de obra" o comparta la
  grabación o las notas de una reunión de proyecto.
metadata:
  version: "0.1.0"
---

# Acta de obra

Producir un acta que sirva como prueba de lo acordado. Un acta útil se
distingue por una sola cosa: **cada compromiso tiene responsable con nombre y
fecha**. Un acta sin eso es un resumen, no un acta.

## Antes de redactar

Leer `PERFIL.md` si existe: numeración, encabezado, actores y tono ya están
definidos ahí. Si no existe, preguntar por el consecutivo del acta anterior
antes de asignar número — nunca inventar la numeración de una serie.

Revisar el acta inmediatamente anterior si está disponible. La verificación de
compromisos previos es la sección que más peso tiene y no se puede escribir sin
ella.

## Regla de separación (no negociable)

El acta tiene dos zonas y no se mezclan:

1. **Cuerpo del acta**: solo lo que efectivamente se dijo y se acordó. Sin
   interpretación, sin suavizar, sin completar lo que faltó. Si alguien dejó
   una idea a medias, se registra a medias.
2. **Sección final "Observaciones de Claude"**, claramente separada y marcada
   como no parte del acta: riesgos detectados, compromisos sin responsable o
   sin fecha, contradicciones con actas anteriores, temas que quedaron sin
   cerrar.

Si un dato no está en la fuente, va como `[POR CONFIRMAR]`. Nunca rellenar.

## Atribución

Cuando la fuente sea un audio o transcripción con hablantes identificables,
atribuir cada posición a quien la sostuvo. Si un hablante no está identificado,
usar `[Hablante no identificado]`, no adivinar por contexto.

## Estructura

```markdown
# ACTA DE COMITÉ DE OBRA N.º [###]

| | |
|---|---|
| **Proyecto** | [Nombre] |
| **Contrato N.º** | [###] |
| **Fecha** | [AAAA-MM-DD] |
| **Hora inicio / fin** | [HH:MM] / [HH:MM] |
| **Lugar / modalidad** | [Obra / virtual] |
| **Elaborada por** | [Nombre y cargo] |

## 1. Asistentes

| Nombre | Cargo | Empresa | Asistió |
|---|---|---|---|
| | | | Sí / No / Delegó en |

Ausencias justificadas: [ ]

## 2. Orden del día
1.
2.

## 3. Verificación de compromisos anteriores

| N.º | Compromiso (Acta ###) | Responsable | Fecha pactada | Estado | Observación |
|---|---|---|---|---|---|
| | | | | Cumplido / En curso / Incumplido / Reprogramado | |

## 4. Desarrollo

### 4.1 [Tema]
[Lo tratado, en pasado impersonal. Registrar posiciones distintas cuando las
haya: "el interventor señaló X; el residente manifestó Y".]

**Decisión:** [Lo que se resolvió, o "no se tomó decisión".]

## 5. Compromisos

| N.º | Compromiso | Responsable | Empresa | Fecha límite |
|---|---|---|---|---|
| | | | | AAAA-MM-DD |

## 6. Temas pendientes para próximo comité
-

## 7. Próxima reunión
Fecha: [ ] · Hora: [ ] · Lugar: [ ]

## 8. Anexos
-

## 9. Firmas

| Nombre | Cargo | Firma |
|---|---|---|
| | | |

---

## Observaciones de Claude — no hacen parte del acta

**Compromisos sin responsable o sin fecha:**
**Riesgos que se mencionaron y no quedaron en compromiso:**
**Contradicciones con actas anteriores:**
**Sugerencias de redacción antes de circular:**
```

## Al entregar

- Preguntar si se entrega en Markdown, Word o PDF. Para firmar: PDF, pero
  guardar el editable.
- Nombrar el archivo según la convención de `PERFIL.md`; si no hay,
  `ACT-###-comite-AAAA-MM-DD`.
- Recordar la regla de circulación: enviar el acta dentro de las 48 horas
  siguientes y fijar un plazo para observaciones. Un acta que se circula una
  semana después ya no se puede objetar de buena fe.
