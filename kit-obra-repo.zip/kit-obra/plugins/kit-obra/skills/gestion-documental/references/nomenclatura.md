# Nomenclatura — detalle y casos límite

## Siglas de tipo documental

| Sigla | Documento |
|---|---|
| `ACT` | Acta (comité, reunión, entrega, vecindad, suspensión, reinicio) |
| `BIT` | Registro de bitácora |
| `INF` | Informe (avance, especial, final) |
| `SC` | Solicitud de cambio / obra adicional |
| `MC` | Mayor cantidad de obra |
| `NC` | No conformidad |
| `RFI` | Consulta técnica |
| `RAD` | Correspondencia radicada |
| `CO` | Corte de obra / acta parcial |
| `ENS` | Ensayo de laboratorio |
| `PL` | Plano |
| `FOT` | Registro fotográfico |

Si la empresa ya usa otras siglas, se conservan las de la empresa. La
consistencia vale más que la elegancia del código.

## Correspondencia: dos series, no una

Llevar series separadas de entrada y salida: `RAD-E-###` y `RAD-S-###`.
Mezclarlas en una sola serie impide contar cuántas comunicaciones propias se
han emitido, que es el dato que se usa en una reclamación.

## Planos

`[DISCIPLINA]-[código]-[descriptor]-V[##]`

Disciplinas: `ARQ`, `EST`, `HID`, `ELE`, `MEC`, `RCI`, `URB`, `TOP`.

Reglas:

- La versión es de dos dígitos y solo sube. No existe `V2.1`; si cambió, es
  `V03`.
- Las versiones superadas se mueven a `SUPERADOS/` el mismo día en que llega la
  nueva. Un plano superado en la carpeta de vigentes es la causa más frecuente
  de reproceso en obra.
- Los planos *récord* (as-built) van en su propia carpeta con sufijo `-REC`.
- Cuando un plano se recibe por correo, se archiva con el radicado que lo
  transmitió referenciado en el índice. Un plano sin trazabilidad de quién lo
  envió y cuándo no sirve para sustentar un cambio.

## Registro fotográfico

`AAAA-MM-DD_[ubicacion]_[descriptor]_[###].jpg`

Ejemplo: `2026-03-04_eje-C-N2_acero-losa_001.jpg`

- La ubicación en el nombre es obligatoria. Una foto sin ubicación no prueba
  nada ocho meses después.
- No renombrar las fotos originales de cámara sin conservar el archivo fuente
  si el proyecto exige metadatos EXIF (fecha y GPS de captura). En ese caso,
  copiar y renombrar la copia.
- Fotografiar siempre lo que va a quedar oculto **antes** de que quede oculto:
  refuerzo antes de fundir, instalaciones antes de tapar, subrasante antes de
  la base.

## Versiones de documentos de trabajo

Para documentos que circulan en revisión, sufijo de estado:
`-BOR` (borrador), `-REV` (en revisión), `-APR` (aprobado), `-FIR` (firmado).

Solo un archivo puede tener `-APR` o `-FIR` por consecutivo. Cuando aparece el
firmado, los borradores se archivan en `_TRABAJO/`, no se borran.

## Errores que cuestan

| Error | Consecuencia |
|---|---|
| Fechas en formato `DD-MM-AA` | Se desordena el listado y se confunde entre países |
| Consecutivo sin ceros | `10` aparece antes que `2` |
| Tildes y ñ | Fallan en plataformas de entrega y en algunos sistemas de archivo |
| Nombres tipo `final_v2_definitivo_ok` | Nadie sabe cuál es el vigente |
| Renombrar un documento ya radicado | Se rompe la cita en otros documentos |
| Carpetas por mes dentro de una serie | Se pierde la continuidad del consecutivo |
