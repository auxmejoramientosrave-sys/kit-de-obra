---
name: gestion-documental
description: >
  Organiza, nombra, radica y hace trazable el archivo de un proyecto de obra:
  nomenclatura de archivos, consecutivos, control de versiones de planos,
  radicación de correspondencia y armado de entregables. Esta skill debe usarse
  cuando el usuario diga "ordena esta carpeta", "cómo nombro estos archivos",
  "arma el expediente", "radica esto", "control de versiones de planos", "no
  encuentro nada en mi carpeta" o "prepara la entrega documental".
metadata:
  version: "0.1.0"
---

# Gestión documental de obra

El archivo de una obra no se juzga por lo ordenado que se ve, sino por una
prueba: **si mañana llega una reclamación sobre un hecho de hace ocho meses,
¿en cuánto tiempo se arma el soporte?** Todo lo que sigue está al servicio de
eso.

## Antes de tocar archivos

1. Leer `PERFIL.md` y la convención que el usuario ya use. **No imponer una
   nomenclatura nueva sobre un archivo que ya tiene una.** Cambiar la
   convención a mitad de proyecto rompe la trazabilidad y es peor que una
   convención mediocre pero consistente.
2. Inventariar antes de mover: listar lo que hay, cuántos archivos, qué
   duplicados, qué está sin nombrar. Mostrarle el inventario al usuario y
   acordar el criterio antes de renombrar nada.
3. **Nunca renombrar ni mover un documento firmado o radicado.** Ese archivo ya
   fue citado por su nombre en otro documento. Si hay que ordenarlo, se copia,
   no se altera el original.

## Nomenclatura

Regla base: `[TIPO]-[###]-[descriptor]-[AAAA-MM-DD]`

- El **tipo** en sigla estable: `ACT`, `BIT`, `INF`, `SC`, `NC`, `RFI`, `RAD`.
- El **consecutivo** siempre con ceros a la izquierda (`007`, no `7`), para que
  el orden alfabético coincida con el cronológico.
- La **fecha en formato AAAA-MM-DD**, siempre. Es el único formato que ordena
  bien y que no se confunde entre convenciones de país.
- Sin tildes, sin ñ, sin espacios, sin caracteres especiales: rompen sistemas
  de archivo de terceros y plataformas de entrega.
- Descriptor corto y específico: `comite`, no `reunion-del-martes`.

Ejemplos: `ACT-012-comite-2026-03-04.pdf` · `SC-003-cimentacion-eje-C-2026-02-18.pdf`

Para **planos**, la versión manda sobre la fecha:
`[DISCIPLINA]-[código]-[descriptor]-V[##]`, p. ej. `EST-P-104-losa-N3-V03.pdf`.
La versión vigente nunca se guarda junto a las anteriores: las superadas van a
`SUPERADOS/`, marcadas, y nunca se borran.

Detalle completo y casos límite en `references/nomenclatura.md`.

## Consecutivos

Un consecutivo es una serie: no se salta, no se repite, no se reusa. Si un
documento se anula, el número **queda anulado** con constancia; no se le asigna
a otro. Mantener el control de la serie en un solo lugar (`registro.md` o una
hoja) con: N.º, fecha, asunto, destinatario, estado, archivo.

Antes de asignar un número nuevo, verificar el último usado. Si no consta,
preguntarle al usuario en vez de deducirlo del archivo más reciente: un
documento sin archivar rompe esa deducción.

## Radicación de correspondencia

Toda comunicación que tenga efecto contractual se radica: número, fecha, hora,
remitente, destinatario, asunto, anexos, y constancia de recibo. Correo
electrónico sirve como radicación si el proyecto lo acepta —verificarlo en el
contrato— y en ese caso se archiva el correo completo con encabezados, no un
pantallazo.

Regla que ahorra reclamaciones: **lo que se acordó por WhatsApp o de palabra no
existe hasta que se radica**. Cuando el usuario cuente un acuerdo informal,
ofrecer redactar la comunicación que lo formaliza el mismo día.

## Armado de expediente y entregables

Cuando el usuario pida armar una entrega o un soporte:

1. Definir el hecho o el alcance a soportar y la fecha de corte.
2. Recolectar en orden cronológico: contrato y otrosíes, planos vigentes de la
   zona, bitácoras del periodo, actas, correspondencia radicada, ensayos,
   registro fotográfico.
3. Producir un **índice** con: consecutivo, tipo, fecha, asunto, folios y
   ubicación del archivo. El índice es el entregable; los documentos son los
   anexos.
4. Señalar los vacíos encontrados. Un expediente con huecos declarados es
   defendible; uno con huecos silenciosos, no.

## Higiene periódica

Ofrecer una revisión mensual que reporte: consecutivos faltantes, documentos
sin firmar, NC y RFI abiertos con más de X días, planos sin versión vigente
identificable, archivos duplicados y archivos fuera de nomenclatura. Entregarlo
como lista de acciones, no como diagnóstico.
