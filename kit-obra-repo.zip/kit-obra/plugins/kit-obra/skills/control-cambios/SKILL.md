---
name: control-cambios
description: >
  Redacta y hace seguimiento a solicitudes de cambio, obras adicionales, no
  conformidades y RFI (consultas técnicas). Esta skill debe usarse cuando el
  usuario diga "solicitud de cambio", "obra adicional", "mayor cantidad de
  obra", "no conformidad", "levanta una NC", "RFI", "consulta a diseño",
  "necesito documentar un cambio" o describa una diferencia entre lo diseñado y
  lo que hay en obra.
metadata:
  version: "0.1.0"
---

# Control de cambios y no conformidades

En obra, casi todo el dinero que se pierde se pierde por cambios que se
ejecutaron antes de quedar documentados. La función de esta skill es cerrar esa
ventana: **el documento se produce antes de ejecutar, no después**.

Si el usuario describe algo que ya ejecutó sin autorización, decírselo con
claridad y ayudarle a documentarlo igual —como hecho cumplido, con esa
etiqueta—, sin redactarlo como si hubiera sido autorizado a tiempo.

## Cuál de los cuatro documentos es

Identificar primero, porque la vía y el destinatario cambian:

| Situación | Documento | Va dirigido a |
|---|---|---|
| Hay una duda o falta información de diseño | **RFI / consulta técnica** | Diseñador, vía interventoría |
| Se requiere ejecutar algo distinto o adicional a lo contratado | **Solicitud de cambio** | Contratante / interventoría |
| Se ejecutó algo que no cumple especificación | **No conformidad** | Contratista ejecutor |
| Es la misma actividad pero en más cantidad | **Mayor cantidad de obra** | Contratante, con soporte de medición |

Distinguir **obra adicional** (ítem que no existe en el contrato: requiere
precio nuevo y usualmente otrosí) de **mayor cantidad de obra** (ítem que sí
existe: se paga al precio unitario pactado). Confundirlas es el error que más
cuesta y el que más discute la interventoría.

## Solicitud de cambio / obra adicional

```markdown
# SOLICITUD DE CAMBIO N.º SC-[###]
**Proyecto:** [ ] · **Fecha:** [AAAA-MM-DD] · **Solicita:** [Nombre, cargo]

## 1. Descripción del cambio
[Qué se pide, en una frase.]

## 2. Situación contractual actual
[Qué dice el contrato, el plano o la especificación hoy. Citar plano y versión,
ítem del presupuesto o numeral de la especificación.]

## 3. Situación encontrada / motivo
[El hecho. Con fecha, ubicación y soporte: bitácora, foto, ensayo, acta.]

## 4. Origen
Diseño incompleto / condición imprevista del sitio / solicitud del cliente /
cambio normativo / error de ejecución. **De este campo depende quién paga.**

## 5. Alternativas evaluadas
| Alternativa | Descripción | Costo | Plazo | Riesgo |
|---|---|---|---|---|
[Mínimo dos. Una solicitud con una sola opción se lee como imposición.]

## 6. Alternativa recomendada y justificación

## 7. Impacto
| | Antes | Después | Diferencia |
|---|---|---|---|
| Costo | | | |
| Plazo (días) | | | |
| Ruta crítica | Sí / No | | |
| Alcance | | | |

## 8. Tipo
Obra adicional (ítem nuevo, requiere APU) / Mayor cantidad (ítem existente) /
Cambio sin impacto económico

## 9. Fecha límite de respuesta
[Fecha a partir de la cual la falta de decisión genera impacto. Nombrar el
impacto concreto.]

## 10. Anexos
Planos, APU, cotizaciones, registro fotográfico, bitácora de referencia.

## 11. Aprobación
| Concepto | Nombre | Fecha | Firma |
|---|---|---|---|
| Solicita | | | |
| Revisa interventoría | | | |
| Aprueba contratante | | | |
```

## No conformidad

Campos mínimos: N.º NC, fecha, detectada por, elemento y ubicación,
requisito incumplido (citando plano, especificación o norma), descripción del
hallazgo, evidencia, clasificación (mayor / menor), tratamiento propuesto
(reprocesar, reparar, aceptar bajo concesión, rechazar), responsable del cierre,
fecha límite, verificación del cierre y firma de quien cierra.

Regla: una NC no se cierra sin evidencia de la verificación. Si el usuario pide
cerrarla sin evidencia, dejarla abierta y decirlo.

## RFI / consulta técnica

Campos mínimos: N.º RFI, fecha, dirigida a, disciplina, referencia (plano y
versión, numeral de especificación), pregunta concreta —una sola por RFI—,
interpretación propuesta por quien pregunta, impacto si no hay respuesta,
**fecha límite de respuesta**, y espacio para la respuesta con fecha y firma.

Una RFI sin fecha límite y sin impacto declarado no genera ninguna urgencia y
por eso no se responde.

## Seguimiento

Mantener un registro consolidado (`04-CAMBIOS/registro.md` o una hoja de
cálculo) con: N.º, tipo, fecha de radicación, días abiertos, estado, impacto en
costo y plazo, y responsable de la decisión pendiente.

Cuando el usuario pida el estado, reportar primero **lo vencido y lo que está
bloqueando obra**, después el resto. El total acumulado de cambios aprobados
frente al valor del contrato es una cifra que conviene tener siempre a la mano:
es la primera que pregunta el cliente.
