# Kit de Obra

Kit de arranque para trabajar con Claude en gestión documental y seguimiento de
obra. Está pensado para que alguien que empieza hoy no arranque desde cero:
formatos que ya tienen criterio, una entrevista inicial que los adapta a su
proyecto, y un revisor que verifica el documento antes de que salga.

## Qué trae

| Skill | Se activa con | Qué hace |
|---|---|---|
| `empezar-aqui` | "empecemos", "configúrame esto", "cambié de proyecto" | Entrevista de arranque. Levanta perfil, lee tus archivos de referencia, escribe `PERFIL.md` y produce tu primer documento real. |
| `acta-obra` | "haz el acta", "acta del comité" | Actas de comité o reunión desde notas, audio o conversación. Separa lo dicho de las recomendaciones. |
| `bitacora-obra` | "bitácora de hoy", "libro de obra" | Registro diario: personal, actividades por ubicación, materiales, ensayos, novedades e instrucciones. |
| `informe-avance` | "informe semanal", "corte de obra", "cómo vamos" | Ejecutado vs. programado, causas de desviación, riesgos y proyección. |
| `control-cambios` | "solicitud de cambio", "no conformidad", "RFI" | Solicitudes de cambio, obra adicional, NC y RFI, con seguimiento consolidado. |
| `gestion-documental` | "ordena esta carpeta", "cómo nombro esto", "arma el expediente" | Nomenclatura, consecutivos, versiones de planos, radicación y armado de expedientes. |
| `app-de-obra` | "hazme una herramienta para", "automatiza este Excel" | Criterio y construcción de herramientas internas: formularios de campo, tableros, consolidadores. |

| Agente | Para qué |
|---|---|
| `revisor-documental` | Revisa un documento antes de firmarlo o enviarlo: completitud, trazabilidad, cifras y exposición contractual. |

## Cómo empezar

Después de instalarlo, escribir en el chat:

```
empecemos
```

Eso dispara `empezar-aqui`. La entrevista toma entre 15 y 30 minutos y termina
con un documento real hecho con tus datos, no con un ejemplo.

**Antes de la entrevista, tener a la mano:** un acta y una bitácora recientes,
la plantilla oficial de la empresa si existe, un informe de avance anterior y
la programación de obra. Con esos archivos el kit se adapta a tus formatos; sin
ellos sale genérico.

## Principios que atraviesan todo el kit

1. **Lo textual y lo interpretado van separados.** Actas e informes registran
   primero lo que se dijo y lo que pasó; las lecturas de Claude van en una
   sección aparte, marcada como tal.
2. **Nada se inventa.** Un dato que falta queda como `[POR CONFIRMAR]`, no
   relleno.
3. **Todo compromiso tiene responsable y fecha.** Sin eso es un resumen, no un
   acta.
4. **Toda cifra se puede rastrear a una fuente.** Lo estimado se marca como
   estimado.
5. **Manda el contrato y la normativa local.** Las referencias normativas del
   kit son de Colombia y son un punto de partida, no una verdad para copiar en
   un documento que vas a firmar.

## Configuración

Ver [CONNECTORS.md](CONNECTORS.md). El kit funciona sin conectores; lo que más
rinde es conectar la carpeta de trabajo desde la app de escritorio.

## Desarrollo de aplicaciones

`app-de-obra` cubre el criterio de dominio: qué construir, para quién y con qué
límites. Para el trabajo técnico se apoya en las skills de ingeniería que ya
trae Claude — `architecture`, `system-design`, `code-review`, `debug`,
`testing-strategy` — en lugar de duplicarlas.

## Ajustarlo

Todos los formatos son un punto de partida. Cuando un documento salga distinto
de como lo necesitas, decirlo en el chat y pedir que se actualice el perfil:
`PERFIL.md` manda sobre las plantillas del kit.
