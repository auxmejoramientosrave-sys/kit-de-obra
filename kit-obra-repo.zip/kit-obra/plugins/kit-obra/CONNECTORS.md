# Conectores

## Cómo funciona

El kit está escrito para funcionar **sin ningún conector**: basta con adjuntar
archivos al chat o conectar una carpeta local desde la app de escritorio. Los
conectores solo quitan pasos manuales.

## Conectores incluidos en la configuración

| Categoría | Servidor sugerido | Para qué sirve en el kit |
|---|---|---|
| Almacenamiento | Google Drive | Leer y escribir actas, informes y planos donde ya viven. Más rápido y más barato que abrirlos por el navegador. |
| Correo | Gmail | Radicar y archivar correspondencia; extraer de un correo la información de una RFI o una solicitud. |
| Calendario | Google Calendar | Comités, fechas límite de RFI y de solicitudes de cambio, cortes de obra. |

Si el usuario trabaja en OneDrive/SharePoint u Outlook, los equivalentes de
Microsoft 365 cumplen la misma función: la lógica de las skills no depende del
proveedor.

## Orden recomendado de conexión

1. **La carpeta de trabajo local** (app de escritorio → "Agregar carpeta"). Es
   lo que más rinde: permite leer, escribir y organizar archivos directamente.
2. **Almacenamiento en la nube**, si el equipo comparte archivos ahí.
3. **Correo**, cuando se empiece a radicar correspondencia con el kit.
4. Lo demás, solo cuando haya una tarea concreta que lo necesite.

## Lo que el kit no necesita

No conectar plataformas de gestión de proyectos ni herramientas de terceros
"por si acaso". Cada conector agrega superficie y consumo sin valor si no hay
una tarea real detrás.
